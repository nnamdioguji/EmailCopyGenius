import { z } from "zod";

export type Screen = 'welcome' | 'input' | 'output';

export interface EmailInputs {
  productDescription: string;
  targetAudience: string;
  goal: string;
  tone: string;
  brandName: string;
  emailType: string;
}

export const emailGoals = [
  'Boost sales',
  'Book calls',
  'Nurture leads',
  'Re-engage subscribers',
  'Announce a new product',
];

export const emailTones = [
  'Friendly',
  'Professional',
  'Luxury',
  'Witty',
  'Empathetic',
  'Bold',
];

export const emailTypes = [
  'Promotional',
  'Welcome',
  'Re-engagement',
  'Abandoned cart',
  'Newsletter',
  'Other'
];

export const emailInputSchema = z.object({
  productDescription: z.string().min(1, "Product description is required"),
  targetAudience: z.string().min(1, "Target audience is required"),
  goal: z.string().min(1, "Goal is required"),
  tone: z.string().min(1, "Tone is required"),
  brandName: z.string().min(1, "Brand name is required"),
  emailType: z.string().min(1, "Email type is required"),
});
