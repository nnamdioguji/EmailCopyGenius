import { useState, useCallback } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import WelcomeScreen from "./components/WelcomeScreen";
import InputScreen from "./components/InputScreen";
import OutputScreen from "./components/OutputScreen";
import { generateEmailCopy } from "./lib/geminiService";
import type { Screen, EmailInputs } from "@shared/schema";

function App() {
  const [screen, setScreen] = useState<Screen>('welcome');
  const [emailInputs, setEmailInputs] = useState<EmailInputs | null>(null);
  const [emailCopy, setEmailCopy] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleGenerate = useCallback(async (inputs: EmailInputs) => {
    setIsLoading(true);
    setEmailInputs(inputs);
    setScreen('output');
    
    if (!emailCopy) {
      setEmailCopy("Generating your email masterpiece...");
    }

    const result = await generateEmailCopy(inputs);
    setEmailCopy(result);
    setIsLoading(false);
  }, [emailCopy]);

  const handleRegenerate = useCallback(() => {
    if (emailInputs) {
      handleGenerate(emailInputs);
    }
  }, [emailInputs, handleGenerate]);

  const renderScreen = () => {
    switch (screen) {
      case 'welcome':
        return <WelcomeScreen onStart={() => setScreen('input')} />;
      case 'input':
        return <InputScreen onGenerate={handleGenerate} isLoading={isLoading} initialData={emailInputs} />;
      case 'output':
        return (
          <OutputScreen
            emailCopy={emailCopy}
            onRegenerate={handleRegenerate}
            onBack={() => setScreen('input')}
            isLoading={isLoading}
          />
        );
      default:
        return <WelcomeScreen onStart={() => setScreen('input')} />;
    }
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen">
          {renderScreen()}
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
