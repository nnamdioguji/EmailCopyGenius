import InputScreen from '../InputScreen';

export default function InputScreenExample() {
  return (
    <InputScreen
      onGenerate={(inputs) => console.log('Generate clicked', inputs)}
      isLoading={false}
      initialData={null}
    />
  );
}
