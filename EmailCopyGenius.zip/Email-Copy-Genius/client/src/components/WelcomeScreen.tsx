import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Sparkles, Zap, Target } from "lucide-react";

interface WelcomeScreenProps {
  onStart: () => void;
}

export default function WelcomeScreen({ onStart }: WelcomeScreenProps) {
  return (
    <div className="flex items-center justify-center min-h-screen p-6">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            Email Copy Genius
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Transform your ideas into persuasive, brand-aligned marketing emails in seconds with AI-powered copywriting
          </p>
        </div>

        <div className="flex justify-center mb-12">
          <Button 
            size="lg" 
            onClick={onStart}
            className="px-8 py-6 text-lg"
            data-testid="button-get-started"
          >
            <Sparkles className="mr-2 h-5 w-5" />
            Get Started
          </Button>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <Card className="p-6">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-primary/10 rounded-lg">
                <Zap className="h-6 w-6 text-primary" />
              </div>
            </div>
            <h3 className="text-lg font-semibold mb-2 text-center">Lightning Fast</h3>
            <p className="text-sm text-muted-foreground text-center">
              Generate professional email copy in seconds, not hours
            </p>
          </Card>

          <Card className="p-6">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-primary/10 rounded-lg">
                <Target className="h-6 w-6 text-primary" />
              </div>
            </div>
            <h3 className="text-lg font-semibold mb-2 text-center">Perfectly Targeted</h3>
            <p className="text-sm text-muted-foreground text-center">
              Customized for your audience, goal, and brand voice
            </p>
          </Card>

          <Card className="p-6">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-primary/10 rounded-lg">
                <Sparkles className="h-6 w-6 text-primary" />
              </div>
            </div>
            <h3 className="text-lg font-semibold mb-2 text-center">AI-Powered</h3>
            <p className="text-sm text-muted-foreground text-center">
              Leverages advanced AI to craft compelling copy every time
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
